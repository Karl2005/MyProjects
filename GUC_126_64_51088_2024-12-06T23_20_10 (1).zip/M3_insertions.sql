﻿--use Milestone2DB_24

--Exec createAllTables    

Insert into customer_profile values(1234567,'Ahmed','Mohamed','Ahmed.Mohamed@gmail.com',
'New cairo 1','10/10/1990')

Insert into customer_account values('01234567890','pass',100, 'pay-as-you-go','10/22/2023',
 'active' ,1000,1234567)

Insert into Service_plan values ('Splan1',100,100,100,100,'Splan1 description')

Insert into Service_plan values ('Splan2',700,100,100,100,'Splan2 description')

Insert into Subscription values ('01234567890',1,'9/23/2024','active')


Insert into Subscription values ('01234567890',2,'9/23/2024','active')


Insert into Plan_Usage values ('10/25/2024','11/25/2024',10,10,10,'01234567890',1)

Insert into Plan_Usage values ('10/25/2024','11/25/2024',10,10,10,'01234567890',2)


insert into Benefits values('Benefit 1 description','1/1/2026', 'active',
'01234567890')
insert into Benefits values('Benefit 2 description','1/1/2026', 'active',
null)
insert into Benefits values('Benefit 3 description','1/1/2026', 'active',
'01234567890')


insert into Exclusive_offer values(1,10,10,10)

insert into plan_provides_benefits values(1,1)

insert into Exclusive_offer values(3,10,10,10)
insert into plan_provides_benefits values(3,1)


insert into Payment values (1000,'10/25/2023','cash','successful','01234567890')
insert into process_payment values (1,1)

insert into Points_group values (1,100,1)


insert into Wallet values(1000, 'egp','10/25/2023' ,'1234567','01234567890')

insert into Cashback values (1,1,700,'10/30/2024')


Insert into customer_profile values (1234555,'Ali','Ahmed','Ali.Ahmed@gmail.com','New Cairo','1/1/1997')

Insert into Wallet values (2000,'egp','1/1/2021',1234555,'01234557890')

Insert into transfer_money values (1,1,70,'1/1/2023')


Insert into transfer_money values (1,1,30,'1/1/2023')


Insert into Service_plan values ('Splan3',100,100,100,100,'Splan3 description')

insert into Technical_support_ticket values('01234567890','issue1_description',1,'Open')
insert into Technical_support_ticket values('01234567890','issue2_description',2,'In progress')

insert into Shop values('Spinneys','Supermarket')
insert into Physical_shop values(1,'New Cairo 1','from 9 to 12')

insert into Shop values('Breadfast','Supermarket')
insert into E_shop values(2,'breadfast.com',5)


insert into Voucher values(100,'1/1/2027',100,'01234567890','1/1/2026',1) 
insert into Voucher values(300,'1/1/2027',700,'01234567890','1/1/2026',2) 


insert into Payment values (10,'10/25/2023','cash','successful','01234567890')

insert into process_payment values (2,2)

insert into Voucher values(300,'1/1/2027',30,null,null,2)

insert into Technical_support_ticket values('01234567890','issue3_description',1,'Resolved')






















